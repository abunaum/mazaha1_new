<?php $__env->startSection('content'); ?>
    <?php if(!$gs->count() && request('cari')): ?>
        <script>
            var err = '<?php echo e(request('cari')); ?>'
            Swal.fire({
                title: 'Ooops!',
                html: 'hasil pencarian "' + err + '" tidak ditemukan.',
                icon: 'error',
                timer: 5000,
                timerProgressBar: true,
                showConfirmButton: false,
                didOpen: () => {
                },
                willClose: () => {
                }
            }).then((result) => {
                /* Read more about handling dismissals below */
                if (result.dismiss === Swal.DismissReason.timer) {
                }
            })
        </script>
    <?php endif; ?>
    <section id="team" class="team section-bg">
        <div class="container" data-aos="fade-up">
            <div class="breadcrumbs" data-aos="fade-in">
                <div class="section-title">
                    <h2>Tenaga Pendidik</h2>
                </div>
                <div class="container mt-3">
                    <div class="row justify-content-center">
                        <div class="col-md-6">
                            <form action="<?php echo e(url('/tenaga-pendidik')); ?>">
                                <div class="input-group mb-3">
                                    <input type="text" class="form-control <?php if(!$gs->count()): ?> is-invalid <?php endif; ?>"
                                           placeholder="Cari" name="cari" value="<?php echo e(request('cari')); ?>">
                                    <div class="input-group-append">
                                        <button class="btn btn-primary" type="submit">Cari</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <?php if($gs->count()): ?>
                    <?php $__currentLoopData = $gs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-6 mb-3">
                            <div class="member d-flex align-items-start" data-aos="zoom-in" data-aos-delay="100">
                                <div class="pic">
                                    <img src="<?php echo e($sp->gambar !== 'user.png' ? asset('storage/'.$sp->gambar) : asset('assets/img/user.png')); ?>" class="img-fluid img-id-<?php echo e($sp->id); ?>" alt="">
                                </div>
                                <div class="member-info">
                                    <h4><?php echo e($sp->name); ?></h4>
                                    <p>Jabatan : <?php echo e($sp->jabatan); ?></p>
                                    <span>Bidang Studi : <?php echo e($sp->bidang_studi === '' ? '-' : $sp->bidang_studi); ?></span>
                                    <p>No HP : <?php echo e($sp->no_hp); ?></p>
                                    <div class="social">
                                            <a onclick="sosial('telegram', '<?php echo e($sp->telegram); ?>')">
                                                <i class="ri-telegram-fill"></i>
                                            </a>
                                            <a onclick="sosial('facebook', '<?php echo e($sp->facebook); ?>')">
                                                <i class="ri-facebook-fill"></i>
                                            </a>
                                            <a onclick="sosial('instagram', '<?php echo e($sp->instagram); ?>')">
                                                <i class="ri-instagram-fill"></i>
                                            </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <div class="col-md-12">
                        <div class="alert alert-danger">
                            Data tidak ditemukan
                        </div>
                    </div>
                <?php endif; ?>
            </div>

            <div class="d-flex justify-content-center mt-3">
                <?php echo e($gs->links()); ?>

            </div>

        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        function sosial(sosial, username) {
            switch (sosial) {
                case 'telegram':
                    if (username === '') {
                        Swal.fire({
                            title: 'Ooops!',
                            html: 'link telegram masih kosong',
                            icon: 'error',
                            timer: 5000,
                            timerProgressBar: true,
                            showConfirmButton: false,
                            didOpen: () => {
                            },
                            willClose: () => {
                            }
                        }).then((result) => {
                            /* Read more about handling dismissals below */
                            if (result.dismiss === Swal.DismissReason.timer) {
                            }
                        })
                    } else {
                        window.open('https://t.me/' + username, '_blank');
                    }
                    break;
                case 'facebook':
                    if (username === '') {
                        Swal.fire({
                            title: 'Ooops!',
                            html: 'link facebook masih kosong',
                            icon: 'error',
                            timer: 5000,
                            timerProgressBar: true,
                            showConfirmButton: false,
                            didOpen: () => {
                            },
                            willClose: () => {
                            }
                        }).then((result) => {
                            /* Read more about handling dismissals below */
                            if (result.dismiss === Swal.DismissReason.timer) {
                            }
                        })
                    } else {
                        window.open('https://facebook.com/' + username, '_blank');
                    }
                    break;
                case 'instagram':
                    if (username === '') {
                        Swal.fire({
                            title: 'Ooops!',
                            html: 'link instagram masih kosong',
                            icon: 'error',
                            timer: 5000,
                            timerProgressBar: true,
                            showConfirmButton: false,
                            didOpen: () => {
                            },
                            willClose: () => {
                            }
                        }).then((result) => {
                            /* Read more about handling dismissals below */
                            if (result.dismiss === Swal.DismissReason.timer) {
                            }
                        })
                    } else {
                        window.open('https://instagram.com/' + username, '_blank');
                    }
                default:
                    break;
            }
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LV\laravel10\core\resources\views/tenaga-pendidik.blade.php ENDPATH**/ ?>