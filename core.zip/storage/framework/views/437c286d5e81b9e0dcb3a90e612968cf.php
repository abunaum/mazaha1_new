<?php $__env->startSection('content'); ?>
    <?php if(session()->has('error')): ?>
        <script>
            var err = '<?php echo e(session('error')); ?>'
            Swal.fire({
                title: 'Ooops!',
                html: err,
                icon: 'error',
                timer: 5000,
                timerProgressBar: true,
                showConfirmButton: false,
                didOpen: () => {
                },
                willClose: () => {
                }
            }).then((result) => {
                /* Read more about handling dismissals below */
                if (result.dismiss === Swal.DismissReason.timer) {
                }
            })
        </script>
    <?php endif; ?>

    <?php if(session()->has('sukses')): ?>
        <script>
            var sks = '<?php echo e(session('sukses')); ?>'
            Swal.fire({
                title: 'Mantap.',
                html: sks,
                icon: 'success',
                timer: 5000,
                timerProgressBar: true,
                showConfirmButton: false,
                didOpen: () => {
                },
                willClose: () => {
                }
            }).then((result) => {
                /* Read more about handling dismissals below */
                if (result.dismiss === Swal.DismissReason.timer) {
                }
            })
        </script>
    <?php endif; ?>

    <!-- ======= Contact Section ======= -->
    <div class="breadcrumbs" data-aos="fade-in">
        <div class="container mt-3">
            <div class="section-title">
                <h2>Sarana prasarana</h2>
            </div>
        </div>
    </div>
    <section id="program-pilihan" class="services section-bg">
        <div class="container" data-aos="fade-up">
            <div class="row">
                <?php for($i = 1; $i <= 12; $i++): ?>
                    <div class="col-xl-4 col-md-6 d-flex align-items-stretch mb-3" data-aos="zoom-in"
                         data-aos-delay="100">
                        <div class="program-box">
                            <div class="text-center">
                                <img src="assets/img/LOGO.png" class="img-thumbnail program-unggulan mb-3"
                                     alt="logo" style="">
                                <h4>Sarana Prasana <?php echo e($i); ?></h4>
                            </div>
                        </div>
                    </div>
                <?php endfor; ?>
            </div>
        </div>
    </section><!-- End Services Section -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LV\laravel10\core\resources\views/sarpras.blade.php ENDPATH**/ ?>