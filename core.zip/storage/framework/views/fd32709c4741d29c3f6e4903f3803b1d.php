<?php $__env->startSection('content'); ?>
    <section id="team" class="team section-bg">
        <div class="container" data-aos="fade-up">
            <div class="breadcrumbs" data-aos="fade-in">
                <div class="section-title">
                    <h2>Struktur organisasi</h2>
                </div>
                <div class="container mt-3">
                    <div class="mb-3 justify-content-center text-center">
                        <img src="<?php echo e(url("assets/img/struktur.png")); ?>" class="img-fluid" style="width: 90%">
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LV\laravel10\core\resources\views/struktur-organisasi.blade.php ENDPATH**/ ?>