<li class="nav-heading">Blog</li>

<li class="nav-item">
    <a class="nav-link <?php if(!isset($tab)): ?> collapsed <?php elseif($tab !== 'Blog'): ?> collapsed <?php endif; ?>" data-bs-target="#blog-nav" data-bs-toggle="collapse" href="#">
        <i class="bi bi-menu-button-wide"></i><span>Blog Data</span><i class="bi bi-chevron-down ms-auto"></i>
    </a>
    <ul id="blog-nav" class="nav-content collapse <?php if(isset($tab)): ?> <?php if($tab === 'Blog'): ?> show <?php endif; ?> <?php endif; ?>" data-bs-parent="#sidebar-nav">
        <li>
            <a href="<?php echo e($url_panel.'/post'); ?>" <?php if($pages === 'Semua Post'): ?> class="active" <?php endif; ?>>
                <i class="bi bi-circle"></i><span>Semua Post</span>
            </a>
        </li>
        <li>
            <a href="<?php echo e($url_panel.'/post/create'); ?>" <?php if($pages === 'Tambah Post'): ?> class="active" <?php endif; ?>>
                <i class="bi bi-circle"></i><span>Tambah Post</span>
            </a>
        </li>

        <li>
            <a href="<?php echo e($url_panel.'/kategori'); ?>" <?php if($pages === 'Kategori'): ?> class="active" <?php endif; ?>>
                <i class="bi bi-circle"></i><span>Kategori</span>
            </a>
        </li>
    </ul>
</li><!-- End Profile Page Nav -->

<?php /**PATH D:\LV\laravel10\core\resources\views/panel/sidebar/media.blade.php ENDPATH**/ ?>