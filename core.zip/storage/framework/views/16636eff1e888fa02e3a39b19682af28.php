<nav id="navbar" class="navbar">
    <ul>
        <li><a class="nav-link scrollto <?php echo e(($pages === 'home') ? 'active' : ''); ?>" href="<?php echo e(url('/')); ?>">Home</a></li>
        <li class="dropdown">
            <a href="#">
                <span>Tentang Kami</span> <i class="bi bi-chevron-down"></i>
            </a>
            <ul>
                <li>
                    <a class="nav-link scrollto" href="<?php echo e(route('sambutan')); ?>">
                        Sambutan Kepala Madrasah
                    </a>
                </li>
                <li>
                    <a class="nav-link scrollto" href="<?php echo e(route('sejarah')); ?>">
                        Sejarah Madrasah
                    </a>
                </li>
                <li>
                    <a class="nav-link scrollto <?php echo e(($pages === 'profile') ? 'active' : ''); ?>"
                       href="<?php echo e(url('/profile')); ?>">
                        Profile Madrasah
                    </a>
                </li>
                <li>
                    <a class="nav-link scrollto <?php echo e(($pages === 'visi-misi') ? 'active' : ''); ?>"
                       href="<?php echo e(url('/visi-misi')); ?>">
                        Visi-Misi
                    </a>
                </li>
                <li>
                    <a class="nav-link scrollto <?php echo e(($pages === 'struktur') ? 'active' : ''); ?>"
                       href="<?php echo e(route('struktur-organisasi')); ?>">
                        Struktur Organisasi
                    </a>
                </li>
                <li>
                    <a class="nav-link scrollto <?php echo e(($pages === 'staff-pengajar') ? 'active' : ''); ?>"
                       href="<?php echo e(url('/tenaga-pendidik')); ?>">
                        Tenaga Pendidik
                    </a>
                </li>
                <li>
                    <a class="nav-link scrollto" href="<?php echo e(url('/tenaga-kependidikan')); ?>">
                        Tenaga Kependidikan
                    </a>
                </li>





            </ul>
        </li>
        <li><a class="nav-link scrollto" href="<?php echo e(route('program-view')); ?>">Program</a></li>


















        <li class="dropdown">
            <a href="#">
                <span>Informasi</span> <i class="bi bi-chevron-down"></i>
            </a>
            <ul>
                <li><a class="nav-link scrollto" href="<?php echo e(url('/berita')); ?>">Berita</a></li>
                <li><a class="nav-link scrollto" href="<?php echo e(route('agenda-list')); ?>">Agenda</a></li>
                <li><a class="nav-link scrollto"
                       href="https://drive.google.com/drive/folders/1MM8y1__qJr4pGJxhXFDqRwdLafBIAM1S" target="_blank">Galeri</a>
                </li>
            </ul>
        </li>
        <li><a class="nav-link scrollto" href="<?php echo e(route('kontak')); ?>">Kontak</a></li>
        <li><a class="getstarted scrollto" href="https://ppsb.mazainulhasan1.sch.id" target="_blank">PPSB</a></li>
    </ul>
    <i class="bi bi-list mobile-nav-toggle"></i>
</nav>
<?php /**PATH D:\LV\laravel10\core\resources\views/layouts/navbar.blade.php ENDPATH**/ ?>