<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">

    <title>MA ZAHA 1 - <?php echo e(strtoupper($pages)); ?></title>
    <link rel="canonical" href="https://mazainulhasan1.sch.id/" />
    <link rel="next" href="https://mazainulhasan1.sch.id" />
    <?php if (! empty(trim($__env->yieldContent('metadata')))): ?>
        <?php echo $__env->yieldContent('metadata'); ?>
    <?php else: ?>
        <meta name="description" content="Website Resmi MA Zainul Hasan 1 Genggong" />
        <meta property="og:description" content="Website Resmi MA Zainul Hasan 1 Genggong" />
    <?php endif; ?>
    <meta property="og:locale" content="id_ID" />
    <meta property="og:type" content="website" />
    <meta property="og:title" content="MA ZAHA 1 Genggong" />
    <meta property="og:url" content="https://mazainulhasan1.sch.id/" />
    <meta property="og:site_name" content="MA ZAHA 1 Genggong" />
    <meta name="twitter:card" content="summary_large_image" />
    <meta name="theme-color" content="#6777ef"/>
    <link rel="apple-touch-icon" href="<?php echo e(asset('malogo.png')); ?>">
    <link rel="manifest" href="<?php echo e(asset('/manifest.json')); ?>">

    <!-- Favicons -->
    <link href="<?php echo e(url('/')); ?>/assets/img/malogo.png" rel="icon">
    <link href="<?php echo e(url('/')); ?>/assets/img/malogo.png" rel="apple-touch-icon">

    <!-- Google Fonts -->
    <link
        href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Jost:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i"
        rel="stylesheet">
    <link href='https://fonts.googleapis.com/css?family=Amiri' rel='stylesheet'>
    <!-- Vendor CSS Files -->
    <link href="<?php echo e(url('/')); ?>/assets/vendor/aos/aos.css" rel="stylesheet">
    <link href="<?php echo e(url('/')); ?>/assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo e(url('/')); ?>/assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
    <link href="<?php echo e(url('/')); ?>/assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
    <link href="<?php echo e(url('/')); ?>/assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
    <link href="<?php echo e(url('/')); ?>/assets/vendor/remixicon/remixicon.css" rel="stylesheet">
    <link href="<?php echo e(url('/')); ?>/assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
    <link href="<?php echo e(url('/')); ?>/assets/panel/vendor/quill/quill.snow.css" rel="stylesheet">
    <link href="<?php echo e(url('/')); ?>/assets/panel/vendor/quill/quill.bubble.css" rel="stylesheet">

    <!-- Template Main CSS File -->
    <link href="<?php echo e(url('/')); ?>/assets/css/style.css" rel="stylesheet">
    <link href="<?php echo e(url('/')); ?>/assets/css/skeleton.css" rel="stylesheet">
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <?php if (! empty(trim($__env->yieldContent('heads')))): ?>
        <?php echo $__env->yieldContent('heads'); ?>
    <?php endif; ?>
</head>

<body>

<!-- ======= Header ======= -->
<header id="header" class="fixed-top ">
    <div class="container d-flex align-items-center">

        <h1 class="logo me-auto">
            <a href="<?php echo e(url('/')); ?>">
                <img src="<?php echo e(url('assets/img/whitelogo.png')); ?>" alt="" class="img-fluid">
            </a>
        </h1>
        <!-- Uncomment below if you prefer to use an image logo -->
        <!-- <a href="index.html" class="logo me-auto"><img src="<?php echo e(url('/')); ?>/assets/img/logo.png" alt="" class="img-fluid"></a>-->
        <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- .navbar -->

    </div>
</header><!-- End Header -->

<!-- ======= Hero Section ======= -->

<?php if (! empty(trim($__env->yieldContent('hero')))): ?>
    <?php echo $__env->yieldContent('hero'); ?>
<?php endif; ?>

<!-- End Hero -->

<main id="main">

    <!-- ======= Clients Section ======= -->
    <?php echo $__env->yieldContent('content'); ?>
    <!-- End Contact Section -->

</main><!-- End #main -->

<!-- ======= Footer ======= -->
<footer id="footer">
    <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</footer><!-- End Footer -->

<div id="preloader"></div>
<a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i
        class="bi bi-arrow-up-short"></i></a>

<!-- Vendor JS Files -->
<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script src="<?php echo e(url('/')); ?>/assets/vendor/aos/aos.js"></script>
<script src="<?php echo e(url('/')); ?>/assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="<?php echo e(url('/')); ?>/assets/vendor/glightbox/js/glightbox.min.js"></script>
<script src="<?php echo e(url('/')); ?>/assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
<script src="<?php echo e(url('/')); ?>/assets/vendor/swiper/swiper-bundle.min.js"></script>
<script src="<?php echo e(url('/')); ?>/assets/vendor/waypoints/noframework.waypoints.js"></script>
<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="<?php echo e(url('/')); ?>/assets/vendor/php-email-form/validate.js"></script>
<script src="https://code.iconify.design/iconify-icon/1.0.2/iconify-icon.min.js"></script>
<script src="<?php echo e(url('/')); ?>/assets/panel/vendor/quill/quill.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/moment@2.29.4/moment.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/moment@2.29.4/locale/id.js"></script>

<!-- Template Main JS File -->
<script src="<?php echo e(url('/')); ?>/assets/js/main.js"></script>
<script src="<?php echo e(asset('/sw.js')); ?>"></script>
<script>
    if (!navigator.serviceWorker.controller) {
        navigator.serviceWorker.register("/sw.js").then(function (reg) {
            console.log("Service worker has been registered for scope: " + reg.scope);
        });
    }
</script>
<?php if (! empty(trim($__env->yieldContent('scripts')))): ?>
    <?php echo $__env->yieldContent('scripts'); ?>
<?php endif; ?>

</body>

</html>
<?php /**PATH D:\LV\laravel10\core\resources\views/layouts/main.blade.php ENDPATH**/ ?>