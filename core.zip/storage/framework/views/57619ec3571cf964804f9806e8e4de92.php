

<?php $__env->startSection('content'); ?>
    <section class="section dashboard">
        <div class="row">
            <div class="col-lg-12">
                <div class="row">
                    <center>
                        <img src="<?php echo e(url('/')); ?>/assets/img/LOGO.png" alt="logo" style="width: 350px;">
                        <h1>Selamat datang di</h1>
                        <h1>Madrasah Aliyah Zainul Hasah 1</h1>
                    </center>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('panel.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LV\laravel10\core\resources\views/panelpage/dashboard.blade.php ENDPATH**/ ?>