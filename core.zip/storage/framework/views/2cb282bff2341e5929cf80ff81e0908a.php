<?php $__env->startSection('metadata'); ?>
    <meta name="description" content="<?php echo e($agenda->judul); ?>"/>
    <meta property="og:description" content="<?php echo e($agenda->judul); ?>"/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="breadcrumbs" data-aos="fade-in">
        <div class="container mt-3">
            <div class="row justify-content-center">
                <div class="col-md-6">
                </div>
            </div>
        </div>
    </div>
    <section>
        <div class="container" data-aos="fade-up">
            <?php if($agenda): ?>
                <div class="card mb-3">
                    <div id="imagediv">
                        <div class="img-thumbnail skeleton" id="skeleton-<?php echo e($agenda->id); ?>"></div>
                        <img class="card-img-top img-id-<?php echo e($agenda->id); ?>" src="#" alt="Card image cap">
                    </div>
                    <div class="card-body">
                        <center>
                            <h2 class="card-title"><?php echo e($agenda->judul); ?></h2>
                            <p class="card-text mb-3">
                                Tempat : <?php echo e($agenda->tempat); ?> ||
                                Waktu : <?php echo e(date('Y-m-d H:i', strtotime($agenda->waktu))); ?>

                            </p>
                        </center>
                        <p class="card-text"><?php echo $agenda->body; ?></p>
                        <center>
                            <div class="mt-3 sharethis-inline-share-buttons">
                                <p>Bagikan : </p>
                                <div class="social-links mt-3">
                                    <a href="https://telegram.me/share/url?url=<?php echo e(url('/berita/detail', $agenda->slug)); ?>&text=<?php echo e($agenda->judul); ?>"
                                       target="_blank">
                                        <iconify-icon icon="logos:telegram" width="32"></iconify-icon>
                                    </a>
                                    <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo e(urlencode(url('/berita/detail', $agenda->slug))); ?>&t=<?php echo e(urlencode($agenda->judul)); ?>"
                                       target="_blank">
                                        <iconify-icon icon="logos:facebook" width="32"></iconify-icon>
                                    </a>
                                    <a href="https://api.whatsapp.com/send?text=<?php echo e($agenda->judul); ?>%20<?php echo e(url('/berita/detail', $agenda->slug)); ?>"
                                       target="_blank">
                                        <iconify-icon icon="logos:whatsapp-icon" width="32"></iconify-icon>
                                    </a>
                                    <a href="https://twitter.com/intent/tweet?text=<?php echo e($agenda->judul); ?>&url=<?php echo e(url('/berita/detail', $agenda->slug)); ?>"
                                       target="_blank">
                                        <iconify-icon icon="skill-icons:twitter" width="32"></iconify-icon>
                                    </a>
                                    <a href="https://www.linkedin.com/shareArticle?token&isFramed=false&url=<?php echo e(url('/berita/detail', $agenda->slug)); ?>"
                                       target="_blank">
                                        <iconify-icon icon="skill-icons:linkedin" width="32"></iconify-icon>
                                    </a>
                                    <a href="https://id.pinterest.com/pin-builder/?description=<?php echo e($agenda->judul); ?>&media=<?php echo e(asset('storage/'.$agenda->gambar)); ?>&method=button&url=<?php echo e(url('/berita/detail', $agenda->slug)); ?>"
                                       target="_blank">
                                        <iconify-icon icon="logos:pinterest" width="32"></iconify-icon>
                                    </a>
                                </div>
                            </div>
                        </center>
                        <hr class="mb-3">
                        <center>
                            <a href="<?php echo e(url('/agenda')); ?>" class="btn btn-primary mb-3">Lihat Semua Agenda</a>
                        </center>
                    </div>
                </div>
            <?php else: ?>
                <center>
                    <h1>Berita tidak ditemukan.</h1>
                </center>
            <?php endif; ?>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).ready(function () {
            const image = $('.img-id-<?php echo e($agenda->id); ?>');
            image.hide();
            var skeleton = $('#skeleton-<?php echo e($agenda->id); ?>');
            const divimage = $('#imagediv');
            const gambar = '<?php echo e($agenda->gambar); ?>';
            if (gambar === 'default-post.jpg') {

                divimage.remove();
            } else {
                changeimage('<?php echo e(asset('storage'.'/'.$agenda->gambar)); ?>', image, skeleton)
            }
        });

        function changeimage(url, image, skeleton) {
            fetch(url)
                .then(response => response.blob())
                .then(blob => {
                    const url = URL.createObjectURL(blob);
                    skeleton.remove();
                    image.show();
                    image.attr('src', url);
                });
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\LV\laravel10\core\resources\views/agenda/detail.blade.php ENDPATH**/ ?>