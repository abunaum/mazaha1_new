<li class="nav-heading">Master Data</li>
<li class="nav-item">
    <a class="nav-link <?php if(!isset($tab)): ?> collapsed <?php elseif($tab !== 'Data Person'): ?> collapsed <?php endif; ?>" data-bs-target="#components-nav" data-bs-toggle="collapse" href="#">
        <i class="bi bi-menu-button-wide"></i><span>Data Person</span><i class="bi bi-chevron-down ms-auto"></i>
    </a>
    <ul id="components-nav" class="nav-content collapse <?php if(isset($tab)): ?> <?php if($tab === 'Data Person'): ?> show <?php endif; ?> <?php endif; ?>" data-bs-parent="#sidebar-nav">
        <li>
            <a href="<?php echo e($url_panel.'/admin/guru-staff'); ?>" <?php if($pages === 'Guru & Staff'): ?> class="active" <?php endif; ?>>
                <i class="bi bi-circle"></i><span>Guru & Staff</span>
            </a>
        </li>





    </ul>
</li>


















<li class="nav-item">
    <a class="nav-link <?php if(!isset($tab)): ?> collapsed <?php elseif($tab !== 'Agenda'): ?> collapsed <?php endif; ?>" data-bs-target="#agenda-nav" data-bs-toggle="collapse" href="#">
        <i class="bi bi-menu-button-wide"></i><span>Data Agenda</span><i class="bi bi-chevron-down ms-auto"></i>
    </a>
    <ul id="agenda-nav" class="nav-content collapse <?php if(isset($tab)): ?> <?php if($tab === 'Agenda'): ?> show <?php endif; ?> <?php endif; ?>" data-bs-parent="#sidebar-nav">
        <li>
            <a href="<?php echo e(route('agenda')); ?>" <?php if($pages === 'Semua Agenda'): ?> class="active" <?php endif; ?>>
                <i class="bi bi-circle"></i><span>Semua Agenda</span>
            </a>
        </li>
        <li>
            <a href="<?php echo e(route('agenda-tambah')); ?>" <?php if($pages === 'Tambah Agenda'): ?> class="active" <?php endif; ?>>
                <i class="bi bi-circle"></i><span>Tambah Agenda</span>
            </a>
        </li>
    </ul>
</li>



















<!-- End Profile Page Nav -->

<?php /**PATH D:\LV\laravel10\core\resources\views/panel/sidebar/admin.blade.php ENDPATH**/ ?>