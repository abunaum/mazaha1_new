<?php
return [
    'nama_panel' => 'MUMTAZ',
    'title_panel' => 'MUMTAZ',
    'url_panel' => '/mumtaz',
];
