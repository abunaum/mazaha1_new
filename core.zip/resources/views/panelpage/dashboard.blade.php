@extends('panel.main')

@section('content')
    <section class="section dashboard">
        <div class="row">
            <div class="col-lg-12">
                <div class="row">
                    <center>
                        <img src="{{ url('/') }}/assets/img/LOGO.png" alt="logo" style="width: 350px;">
                        <h1>Selamat datang di</h1>
                        <h1>Madrasah Aliyah Zainul Hasah 1</h1>
                    </center>
                </div>
            </div>
        </div>
    </section>
@endsection
