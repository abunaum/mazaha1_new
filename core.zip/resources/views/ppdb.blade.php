@extends('layouts.main')

@section('content')
    <div class="breadcrumbs" data-aos="fade-in">
        <div class="container mt-3">
            <center>
                <h2>Penerimaan Peserta Didik Baru</h2>
            </center>
        </div>
    </div>
    <section>
        <div class="container" data-aos="fade-up">
            <center>
                <h1>PPDB MA ZAHA 1 Sedang Ditutup</h1>
            </center>
        </div>
    </section>
@endsection
