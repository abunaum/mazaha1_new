<footer id="footer" class="footer">
    <div class="copyright">
        &copy; Copyright <strong><span>MA ZAHA 1</span></strong>. All Rights Reserved
    </div>
    <div class="credits">
        Designed by <a href="https://t.me/@abu_naum">Ahmad Yani</a>
    </div>
</footer>
