<div class="footer-top">
    <div class="container">
        <div class="row">

            <div class="col-lg-3 col-md-6 footer-contact">
                <img src="{{ url('assets/img/blacklogo.png') }}" alt="" style="width: 15rem">
                <p>
                    Jl. Raya Condong No.12, Gerojokan<br>
                    Karangbong, Kec. Pajarakan<br>
                    Kab. Probolinggo, Jawa Timur, 67281<br>
                    <strong>Telepon:</strong> (0335) 842253<br>
                    <strong>Email:</strong> mazainulhasan1@gmail.com<br>
                </p>
            </div>

            <div class="col-lg-3 col-md-6 footer-links">
                <h4>Link</h4>
                <ul>
                    <li><i class="bx bx-chevron-right"></i> <a href="{{ url('/profile') }}">Profile</a></li>
                    <li><i class="bx bx-chevron-right"></i> <a href="{{ url('/visi-misi') }}">Visi & Misi</a></li>
                    <li><i class="bx bx-chevron-right"></i> <a href="{{ url('/tenaga-pendidik') }}">Tenaga Pendidik</a></li>
                    <li><i class="bx bx-chevron-right"></i> <a href="{{ url('/tenaga-kependidikan') }}">Tenaga Kependidikan</a></li>
                </ul>
            </div>

            <div class="col-lg-3 col-md-6 footer-links">
                <h4>Layanan</h4>
                <ul>
                    <li><i class="bx bx-chevron-right"></i> <a href="https://ppsb.mazainulhasan1.sch.id" target="_blank">PSB</a></li>
                    <li><i class="bx bx-chevron-right"></i> <a href="https://simumtaz.mazainulhasan1.sch.id" target="_blank">SIMUMTAZ</a></li>
                    <li><i class="bx bx-chevron-right"></i> <a href="{{ url('/berita') }}">Berita</a></li>
                    <li><i class="bx bx-chevron-right"></i> <a href="{{ url('/agenda') }}">Agenda</a></li>
                </ul>
            </div>

            <div class="col-lg-3 col-md-6 footer-links">
                <h4>Sosial Media Kami</h4>
                <p>Hubungi kami via sosial media</p>
                <div class="social-links mt-3">
                    <a href="https://t.me/ma_zahagenggong" class="twitter"><i class="bx bxl-telegram"></i></a>
                    <a href="https://www.facebook.com/mazahagenggong" class="facebook"><i
                            class="bx bxl-facebook"></i></a>
                    <a href="https://www.instagram.com/ma_zahagenggong" class="instagram"><i
                            class="bx bxl-instagram"></i></a>
                    <a href="https://www.youtube.com/@mazaha1genggong879" class="google-plus"><i class="bx bxl-youtube"></i></a>
                </div>
            </div>

        </div>
    </div>
</div>

<div class="container footer-bottom clearfix">
    <div class="copyright">
        &copy; Copyright <strong><span>MA ZAHA 1</span></strong>. All Rights Reserved
    </div>
    <div class="credits">
        Developed by TIM IT MA Zainul Hasan 1 Genggong
    </div>
</div>
